'use strict';

require('dotenv').config();

const express = require('express');
const cors = require('cors');

const config = require('./src/config');
const logger = require('./src/utils/logger');
const { ensureDir } = require('./src/utils/fileUtils');

const {
  helmetMiddleware,
  permissionsPolicy,
  hostHeaderProtection,
  noDirectoryListing,
  generalRateLimiter,
  sessionMiddleware,
  cookieParser,
  hpp,
  noSqlSanitizer
} = require('./src/middlewares/security');
const { xssAndInjectionGuard } = require('./src/middlewares/sanitize');
const { banGuard, visitLogger } = require('./src/middlewares/tracking');
const { notFoundHandler, errorHandler } = require('./src/middlewares/errorHandler');

const pagesRoutes = require('./src/routes/pages.routes');
const uploadRoutes = require('./src/routes/upload.routes');
const filesRoutes = require('./src/routes/files.routes');
const adminRoutes = require('./src/routes/admin.routes');
const gdprRoutes = require('./src/routes/gdpr.routes');

ensureDir(config.uploadsDir);
ensureDir(config.logsDir);

const app = express();

// Required for correct client IP resolution behind a reverse proxy (Railway,
// Nginx, Cloudflare, etc.) - must be set before any IP-dependent middleware.
app.set('trust proxy', config.trustProxy);

// ────────────────────────────────────────────────
// Security headers & hardening (applied first)
// ────────────────────────────────────────────────
app.use(hostHeaderProtection);
app.use(helmetMiddleware);
app.use(permissionsPolicy);
app.use(hpp);
app.use(cookieParser);
app.use(sessionMiddleware);

app.use(cors({
  origin: config.corsOrigins.includes('*') ? true : config.corsOrigins,
  credentials: true,
  methods: ['GET', 'POST', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Session-Id', 'X-Api-Key', 'X-CSRF-Token', 'X-Timezone']
}));

app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true, limit: '2mb' }));

app.use(noSqlSanitizer);
app.use(xssAndInjectionGuard);

app.use(generalRateLimiter);

// ────────────────────────────────────────────────
// Visitor tracking & ban enforcement
// ────────────────────────────────────────────────
app.use(banGuard);
app.use(visitLogger);

// ────────────────────────────────────────────────
// Static assets (no directory listing, cached sensibly)
// ────────────────────────────────────────────────
app.use(noDirectoryListing(config.publicDir));
app.use(express.static(config.publicDir, {
  index: false, // prevent implicit directory index / listing surprises
  setHeaders: (res, filePath) => {
    if (filePath.endsWith('.js')) {
      res.setHeader('Content-Type', 'application/javascript');
    }
  }
}));

// ────────────────────────────────────────────────
// Routes (all original routes preserved)
// ────────────────────────────────────────────────
app.use(pagesRoutes);
app.use(uploadRoutes);
app.use(filesRoutes);
app.use(adminRoutes);
app.use(gdprRoutes);

app.get('/health', (req, res) => {
  res.status(200).json({ status: 'ok', uptime: process.uptime() });
});

app.use(notFoundHandler);
app.use(errorHandler);

app.listen(config.port, '0.0.0.0', () => {
  logger.info(`DROPX server listening on port ${config.port}`);
  console.log(`✅ DROPX شغال — البورت ${config.port}`);
  console.log(`🛡️  الأمان: Helmet + Rate Limit + CSRF + XSS + Session مفعّلة`);
  console.log(`📏 حد الرفع: ${(config.quotas.userQuota / 1048576).toFixed(0)}MB/يوزر`);
  console.log(`🌐 Server is ready and listening!`); // Signal for Pterodactyl
});

process.on('unhandledRejection', (reason) => {
  logger.error('Unhandled promise rejection', { reason: reason && reason.message });
});
process.on('uncaughtException', (err) => {
  logger.error('Uncaught exception', { error: err.message, stack: err.stack });
});
