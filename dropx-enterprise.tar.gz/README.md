# DROPX / N-DROP — Enterprise Edition

منصة رفع ملفات ذاتية الاستضافة، أُعيدت هيكلتها بالكامل لتشمل طبقة أمان enterprise-grade،
تسجيل زوّار تفصيلي لكل IP، لوحة إدارة، وواجهة برمجية للامتثال لحذف بيانات المستخدم (GDPR-style).

جميع المسارات (Routes) الأصلية محفوظة بنفس الشكل ولم يتغير أي سلوك ظاهري للموقع.

## التشغيل

```bash
npm install
cp .env.example .env
# عدّل القيم في .env (خصوصًا SESSION_SECRET وADMIN_PASSWORD_HASH)
npm start
```

**قبل النشر في بيئة إنتاج، غيّر إلزاميًا:**

- `SESSION_SECRET` — نص عشوائي طويل (`openssl rand -hex 32`)
- `ADMIN_PASSWORD_HASH` — شغّل:
  `node -e "console.log(require('crypto').createHash('sha256').update('كلمة_المرور').digest('hex'))"`
  وضع الناتج في المتغير. بدون تعيينه، تسجيل دخول الأدمن سيبقى مرفوضًا دائمًا (سلوك آمن افتراضيًا).
- `ALLOWED_HOSTS` — أضف نطاقاتك الحقيقية لتفعيل الحماية من هجمات Host header.
- `SESSION_SECURE_COOKIE=true` بمجرد تفعيل HTTPS.
- `TRUST_PROXY` — اضبطه على **عدد** البروكسيات الحقيقية أمام تطبيقك (عادة `1` إذا
  كان خلف بروكسي واحد فقط مثل Railway/Nginx/Cloudflare). **لا تضعه أبدًا `true`** —
  هذا يعني الثقة بأي قيمة `X-Forwarded-For` يرسلها أي شخص، ما يسمح بتزوير الـ IP
  وتجاوز الحظر (Ban) والكوتا و Rate Limiting بالكامل.

## البنية

```
src/
  config/         إعدادات مركزية عبر متغيرات البيئة
  routes/         تعريف المسارات فقط (بدون منطق)
  controllers/    منطق التعامل مع الطلبات
  services/       منطق الأعمال (meta, logs, bans, audit, geo)
  middlewares/    الأمان، رفع الملفات، التتبّع، معالجة الأخطاء
  utils/          دوال مساعدة عامة (hashing, sanitizing, validation)
data/             meta.json, bans.json, audit.log  (لا تُرفع لـ git)
logs/<IP>/        سجلات كل زائر على حدة
uploads/          الملفات المرفوعة (أسماء UUID)
public/           نفس الواجهات الأصلية + admin.html/js الجديدة
```

## الأمان المطبّق

| الحماية | التطبيق |
|---|---|
| Helmet (CSP, HSTS, إلخ) | `src/middlewares/security.js` |
| Rate Limiting (عام + رفع + دخول أدمن) | `express-rate-limit`, حدود منفصلة |
| CSRF | `csrf-csrf` (double-submit cookie)، مُستثنى فقط لعملاء API (مفتاح API/Authorization) |
| XSS | تنظيف كل مدخلات body/query عبر مكتبة `xss` |
| SQL/NoSQL Injection | نمط SQLi + إزالة مفاتيح `$`/`__proto__` |
| Path Traversal | `safeResolve()` قبل أي وصول لملف على القرص |
| Directory Listing | يمنع الوصول لأي مجلد كملف مباشر |
| Clickjacking | `X-Frame-Options: SAMEORIGIN` + `frame-ancestors` |
| MIME Sniffing | `X-Content-Type-Options: nosniff` |
| Host Header Attack | قائمة `ALLOWED_HOSTS` (اختياري، مُعطّل افتراضيًا حتى تُفعّله) |
| HPP | `hpp` يمنع تلاعب المعاملات المكررة |

### فحص الملفات المرفوعة

- فحص Magic Bytes (يكتشف EXE/ELF/Mach-O/JAR حتى لو غُيّر الامتداد)
- حظر امتدادات تنفيذية معروفة (`.exe .bat .php .sh ...`)
- كشف الامتداد المزدوج (`invoice.pdf.exe`)
- SHA-256 لكل ملف + منع رفع نفس المحتوى مرتين (dedupe)
- إعادة تسمية فورية بـ UUID (الاسم الأصلي يُحفظ فقط كـ metadata)
- حد أقصى للحجم ولعدد الطلبات لكل جلسة/IP
- كل محاولة رفع فاشلة تُسجَّل في `logs/<IP>/uploads.log`

## نظام السجلات (Logs)

لكل IP مجلد مستقل تحت `logs/`، يحتوي:

- `info.json` — أول/آخر ظهور، عدد الزيارات، آخر معلومات جهاز/دولة
- `visits.log` — سجل تفصيلي لكل زيارة (User Agent، متصفح، نظام تشغيل، جهاز، لغة، دولة، مدينة، Referrer، Headers، إلخ)
- `pages.log` — الصفحات التي زارها
- `uploads.log` — كل عمليات الرفع الناجحة والفاشلة
- `downloads.log` — كل عملية تحميل ملف
- `errors.log` — أي خطأ مرتبط بهذا الـ IP

## لوحة الإدارة

`/admin` — محمية بجلسة + CSRF. الإحصاءات، البحث بـ IP/Session/اسم ملف، حذف ملف أو كل ملفات
مستخدم أو كل سجلاته، Ban/Unban، Blacklist/Whitelist، وسجل تدقيق (`/api/admin/audit`).

الحساب الافتراضي معطّل حتى تضبط `ADMIN_USERNAME` و`ADMIN_PASSWORD_HASH` (أو `ADMIN_PASSWORD` للتجربة السريعة فقط).

## حذف بيانات المستخدم (الامتثال للخصوصية)

```
DELETE /api/user-data
```

يحذف كل ملفات ومنطق/سجلات صاحب الطلب (بحسب IP والجلسة)، ويُسجَّل تنفيذ الحذف نفسه في
`data/audit.log` دون أي محتوى شخصي. محمي بـ CSRF لعملاء المتصفح (عملاء API بمفتاح/Authorization معفوّن).

## ملاحظة حول سياسة أمان المحتوى (CSP)

لاحظت أن `index.html`/`contact.html` يحمّلان سكربت إعلانات من نطاق خارجي (`quge5.com`).
الـ CSP الجديدة الصارمة (`script-src 'self' 'unsafe-inline'`) **لا تسمح** بهذا النطاق عمدًا،
لأنه نطاق إعلانات غير موثّق يتعارض مع هدف "أمان enterprise". إن أردت الإبقاء عليه، أضف
النطاق صراحة إلى `scriptSrc`/`connectSrc` في `src/middlewares/security.js` مع العلم أنه
سيقلل من صرامة الحماية.

## ما تم اختباره فعليًا

نظرًا لعدم توفر اتصال إنترنت في بيئة التنفيذ التي أنشأت بها المشروع، لم أتمكن من تشغيل
`npm install` الحقيقي هناك. بدلاً من ذلك بنيت نسخًا محلية مطابقة لسلوك كل مكتبة (Express،
multer، helmet، express-session، csrf-csrf، إلخ)، شغّلت الخادم الحقيقي عليها، وأرسلت
طلبات HTTP فعلية لاختبار: كل الصفحات، الرفع (نجاح/تكرار/رفض حجم/رفض كوتا)، فحص الملفات
الخبيثة (امتداد محظور، امتداد مزدوج، Magic Bytes)، التحميل، الحذف، تسجيل دخول/خروج الأدمن،
Ban/Unban/Blacklist/Whitelist، البحث، حذف ملفات/سجلات مستخدم، CSRF (قبول/رفض)، Rate
Limiting، الجلسات، السجلات لكل IP، وحذف بيانات GDPR. وجدت وأصلحت عدة أخطاء حقيقية أثناء
ذلك (أبرزها: حجب الصفحة الرئيسية بالخطأ بواسطة حارس منع فهرسة المجلدات، وربط CSRF بجلسة
لم تكن تُحفظ للزوار المجهولين). يُنصح بتشغيل `npm install && npm start` على جهازك والتأكد
من عمل كل شيء كما هو متوقع في بيئتك الفعلية.
