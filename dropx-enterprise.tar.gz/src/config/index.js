'use strict';

const path = require('path');

const ROOT_DIR = path.join(__dirname, '..', '..');

function bool(val, def) {
  if (val === undefined) return def;
  return String(val).toLowerCase() === 'true';
}

function num(val, def) {
  const n = Number(val);
  return Number.isFinite(n) ? n : def;
}

module.exports = {
  env: process.env.NODE_ENV || 'production',
  port: num(process.env.PORT, 25439),
  baseUrl: process.env.BASE_URL || 'https://ndrop.hidenfree.com',

  rootDir: ROOT_DIR,
  uploadsDir: path.join(ROOT_DIR, 'uploads'),
  logsDir: path.join(ROOT_DIR, 'logs'),
  publicDir: path.join(ROOT_DIR, 'public'),
  metaFile: path.join(ROOT_DIR, 'data', 'meta.json'),
  banFile: path.join(ROOT_DIR, 'data', 'bans.json'),
  auditFile: path.join(ROOT_DIR, 'data', 'audit.log'),

  session: {
    secret: process.env.SESSION_SECRET || 'CHANGE_ME_SESSION_SECRET_' + Math.random().toString(36).slice(2),
    cookieMaxAgeMs: num(process.env.SESSION_MAX_AGE_MS, 1000 * 60 * 60 * 24 * 7), // 7 days
    secureCookie: bool(process.env.SESSION_SECURE_COOKIE, false)
  },

  admin: {
    username: process.env.ADMIN_USERNAME || 'admin',
    // Default password is intentionally strong-random; MUST be overridden via env in production.
    passwordHash: process.env.ADMIN_PASSWORD_HASH || null,
    // Plain fallback only for first-run convenience; strongly recommended to use ADMIN_PASSWORD_HASH instead.
    password: process.env.ADMIN_PASSWORD || null
  },

  quotas: {
    userQuota: num(process.env.USER_QUOTA_BYTES, 200 * 1024 * 1024),  // 200MB
    apiQuota: num(process.env.API_QUOTA_BYTES, 500 * 1024 * 1024),    // 500MB
    maxFileSize: num(process.env.MAX_FILE_SIZE_BYTES, 200 * 1024 * 1024)
  },

  rateLimit: {
    windowMs: num(process.env.RATE_LIMIT_WINDOW_MS, 15 * 60 * 1000),
    max: num(process.env.RATE_LIMIT_MAX, 300),
    uploadWindowMs: num(process.env.UPLOAD_RATE_LIMIT_WINDOW_MS, 60 * 1000),
    uploadMax: num(process.env.UPLOAD_RATE_LIMIT_MAX, 10)
  },

  // A boolean `true` here would trust the X-Forwarded-For header from ANY
  // client, letting anyone spoof their IP and bypass rate limiting entirely.
  // Default to trusting exactly one hop (the platform's own reverse proxy /
  // load balancer - e.g. Railway, Nginx, Cloudflare in front of it). Override
  // via TRUST_PROXY if you have a different number of proxies in front of
  // the app, or set it to a specific proxy IP/CIDR list.
  trustProxy: (() => {
    const raw = process.env.TRUST_PROXY;
    if (raw === undefined) return 1;
    if (raw === 'true') return true;
    if (raw === 'false') return false;
    const n = Number(raw);
    return Number.isFinite(n) ? n : raw; // allow IP/CIDR strings too
  })(),

  allowedHosts: (process.env.ALLOWED_HOSTS || '')
    .split(',')
    .map(s => s.trim())
    .filter(Boolean),

  corsOrigins: (process.env.CORS_ORIGINS || '*')
    .split(',')
    .map(s => s.trim())
    .filter(Boolean)
};
