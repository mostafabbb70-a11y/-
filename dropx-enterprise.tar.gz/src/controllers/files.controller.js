'use strict';

const fs = require('fs');
const path = require('path');
const config = require('../config');
const metaService = require('../services/metaService');
const logService = require('../services/logService');
const { safeResolve } = require('../utils/fileUtils');
const { normalizeIp, isValidShortId } = require('../utils/validators');

const fmtSize = b => (b < 1024 ? b + ' B' : b < 1048576 ? (b / 1024).toFixed(1) + ' KB' : (b / 1048576).toFixed(2) + ' MB');

const NOT_FOUND_PAGE = `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>DROPX — الملف غير موجود</title>
<style>*{margin:0;padding:0;box-sizing:border-box;}body{background:#060b12;color:#deeeff;font-family:Cairo,sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;}.box{text-align:center;padding:40px 24px;}.ico{font-size:64px;margin-bottom:16px;}h1{font-size:22px;font-weight:700;margin-bottom:8px;}p{color:#4d7090;font-size:14px;line-height:1.8;}a{display:inline-block;margin-top:24px;padding:12px 28px;background:linear-gradient(135deg,#004eee,#00c8f0);border-radius:12px;color:white;text-decoration:none;font-weight:700;}</style>
</head><body><div class="box"><div class="ico">🔍</div><h1>الملف غير موجود</h1><p>الرابط غير صحيح أو تم حذف الملف</p><a href="/">↩ الرئيسية</a></div></body></html>`;

async function downloadByShortId(req, res) {
  const sid = req.params.sid;
  const ip = normalizeIp(req.ip);

  if (!isValidShortId(sid)) {
    return res.status(404).send(NOT_FOUND_PAGE);
  }

  const meta = metaService.findByShortId(sid);
  if (!meta) {
    return res.status(404).send(NOT_FOUND_PAGE);
  }

  // Path-traversal safe resolution: filename is server-generated (UUID) but
  // we still validate it resolves inside the uploads directory.
  const fp = safeResolve(config.uploadsDir, meta.filename);
  if (!fp || !fs.existsSync(fp)) {
    await metaService.deleteMeta(sid);
    return res.status(404).send('الملف غير موجود');
  }

  await metaService.incrementDownload(sid);
  logService.recordDownload(ip, { shortId: sid, name: meta.name });

  res.sendFile(fp);
}

function listFiles(req, res) {
  const sid = req.headers['x-session-id'] || req.query.session || normalizeIp(req.ip);
  const files = metaService.findBySession(sid);
  res.json({ success: true, count: files.length, files });
}

async function deleteFile(req, res) {
  const sid = req.params.sid;
  const sessionId = req.headers['x-session-id'] || normalizeIp(req.ip);

  if (!isValidShortId(sid)) {
    return res.status(404).json({ success: false, error: 'غير موجود' });
  }

  const meta = metaService.findByShortId(sid);
  if (!meta) return res.status(404).json({ success: false, error: 'غير موجود' });
  if (meta.sessionId !== sessionId) return res.status(403).json({ success: false, error: 'غير مسموح' });

  const fp = safeResolve(config.uploadsDir, meta.filename);
  try {
    if (fp && fs.existsSync(fp)) fs.unlinkSync(fp);
  } catch { /* noop */ }

  await metaService.deleteMeta(sid);
  res.json({ success: true });
}

function stats(req, res) {
  const sid = req.headers['x-session-id'] || req.query.session || normalizeIp(req.ip);
  const files = metaService.findBySession(sid);
  const used = files.reduce((s, f) => s + (f.size || 0), 0);
  res.json({
    success: true,
    count: files.length,
    used: fmtSize(used),
    quota: fmtSize(config.quotas.userQuota),
    percent: Math.min(100, Math.round((used / config.quotas.userQuota) * 100)),
    raw: { used, quota: config.quotas.userQuota }
  });
}

module.exports = { downloadByShortId, listFiles, deleteFile, stats };
