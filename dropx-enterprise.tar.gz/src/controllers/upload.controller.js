'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const config = require('../config');
const metaService = require('../services/metaService');
const logService = require('../services/logService');
const { scanMagicBytes } = require('../middlewares/uploadSecurity');
const { sanitizeFilename, sha256File } = require('../utils/fileUtils');
const { normalizeIp } = require('../utils/validators');
const logger = require('../utils/logger');

const fmtSize = b => (b < 1024 ? b + ' B' : b < 1048576 ? (b / 1024).toFixed(1) + ' KB' : (b / 1048576).toFixed(2) + ' MB');
const shortId = () => crypto.randomBytes(4).toString('hex');
const getBase = req => config.baseUrl || `${req.protocol}://${req.get('host')}`;

async function handleUpload(req, res) {
  const ip = normalizeIp(req.ip);

  if (!req.file) {
    return res.status(400).json({ success: false, error: 'لم يتم إرسال ملف' });
  }

  const cleanup = () => { try { fs.unlinkSync(req.file.path); } catch { /* noop */ } };

  const sessionId = req.headers['x-session-id'] || req.body.sessionId || ip;
  const isApi = req.headers['x-api-key'] !== undefined || req.headers['authorization'] !== undefined;
  const quota = isApi ? config.quotas.apiQuota : config.quotas.userQuota;
  const used = metaService.getSessionUsage(sessionId);

  // Quota check
  if (used + req.file.size > quota) {
    cleanup();
    logService.recordFailedUpload(ip, { reason: 'quota_exceeded', sessionId, size: req.file.size });
    return res.status(429).json({
      success: false,
      error: `تجاوزت الحد المسموح (${fmtSize(quota)})`,
      used: fmtSize(used),
      quota: fmtSize(quota),
      remaining: fmtSize(Math.max(0, quota - used))
    });
  }

  // Magic-byte security scan (executables, disguised binaries)
  const scan = scanMagicBytes(req.file.path);
  if (!scan.safe) {
    cleanup();
    logService.recordFailedUpload(ip, { reason: scan.reason, originalName: req.file.originalname, sessionId });
    return res.status(400).json({ success: false, error: '⚠️ ' + scan.reason, blocked: true });
  }

  // Hash the file & block exact duplicate uploads
  let hash;
  try {
    hash = await sha256File(req.file.path);
  } catch (err) {
    cleanup();
    logger.error('Hashing failed', { error: err.message });
    return res.status(500).json({ success: false, error: 'خطأ أثناء معالجة الملف' });
  }

  const existing = metaService.findByHash(hash);
  if (existing) {
    cleanup();
    return res.json({
      success: true,
      duplicate: true,
      url: existing.url,
      file: { name: existing.name, size: existing.size, type: existing.type, shortId: existing.shortId }
    });
  }

  const sid = shortId();
  const url = `${getBase(req)}/f/${sid}`;
  const info = {
    shortId: sid,
    filename: req.file.filename,
    name: sanitizeFilename(req.file.originalname),
    size: req.file.size,
    type: req.file.mimetype,
    sha256: hash,
    url,
    date: new Date().toISOString(),
    sessionId,
    ip,
    downloads: 0
  };

  await metaService.saveMeta(info);
  logService.recordUpload(ip, { shortId: sid, name: info.name, size: info.size, sessionId, sha256: hash });

  res.json({
    success: true,
    url,
    file: { name: info.name, size: info.size, type: info.type, shortId: sid },
    usage: {
      used: fmtSize(used + req.file.size),
      quota: fmtSize(quota),
      remaining: fmtSize(quota - used - req.file.size),
      percent: Math.round(((used + req.file.size) / quota) * 100)
    }
  });
}

module.exports = { handleUpload, fmtSize, getBase };
