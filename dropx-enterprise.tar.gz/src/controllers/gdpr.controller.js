'use strict';

const fs = require('fs');
const config = require('../config');
const metaService = require('../services/metaService');
const logService = require('../services/logService');
const auditService = require('../services/auditService');
const { safeResolve } = require('../utils/fileUtils');
const { normalizeIp, isValidSessionId } = require('../utils/validators');

/**
 * DELETE /api/user-data
 * Deletes all files, logs, and session data associated with the requester's
 * IP and/or session ID, and records the action in the audit log.
 *
 * Body (optional): { sessionId } - if provided, also removes files tied to
 * that session ID even if uploaded from a different IP.
 */
async function deleteUserData(req, res) {
  const ip = normalizeIp(req.ip);
  const bodySessionId = req.body && req.body.sessionId;
  const headerSessionId = req.headers['x-session-id'];
  const sessionId = isValidSessionId(bodySessionId) ? bodySessionId
    : (isValidSessionId(headerSessionId) ? headerSessionId : null);

  let removedFiles = await metaService.deleteMetaByIp(ip);
  if (sessionId) {
    const bySession = await metaService.deleteMetaBySession(sessionId);
    removedFiles = removedFiles.concat(bySession);
  }

  for (const meta of removedFiles) {
    const fp = safeResolve(config.uploadsDir, meta.filename);
    try { if (fp && fs.existsSync(fp)) fs.unlinkSync(fp); } catch { /* noop */ }
  }

  const logsDeleted = logService.deleteIpLogs(ip);

  // Destroy any active session tied to this request.
  if (req.session) {
    req.session.destroy(() => {});
  }

  auditService.record('user_data_deletion', {
    ip,
    sessionId,
    filesDeleted: removedFiles.length,
    logsDeleted,
    requestedBy: 'user'
  });

  res.json({
    success: true,
    message: 'تم حذف جميع بياناتك بنجاح',
    details: {
      filesDeleted: removedFiles.length,
      logsDeleted
    }
  });
}

module.exports = { deleteUserData };
