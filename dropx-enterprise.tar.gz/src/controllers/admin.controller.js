'use strict';

const fs = require('fs');
const path = require('path');
const config = require('../config');
const metaService = require('../services/metaService');
const logService = require('../services/logService');
const banService = require('../services/banService');
const auditService = require('../services/auditService');
const { verifyPassword } = require('../middlewares/adminAuth');
const { safeResolve } = require('../utils/fileUtils');
const { isValidIp, isValidSessionId, isValidShortId } = require('../utils/validators');
const logger = require('../utils/logger');

function login(req, res) {
  const { username, password } = req.body || {};
  if (!username || !password || !verifyPassword(username, password)) {
    auditService.record('admin_login_failed', { username, ip: req.ip });
    return res.status(401).json({ success: false, error: 'بيانات الدخول غير صحيحة' });
  }
  req.session.isAdmin = true;
  req.session.adminUser = username;
  auditService.record('admin_login_success', { username, ip: req.ip });
  res.json({ success: true });
}

function logout(req, res) {
  auditService.record('admin_logout', { username: req.session.adminUser, ip: req.ip });
  req.session.isAdmin = false;
  res.json({ success: true });
}

function whoami(req, res) {
  res.json({ success: true, isAdmin: !!req.session.isAdmin, username: req.session.adminUser || null });
}

function overview(req, res) {
  const files = metaService.all();
  const ips = logService.listAllIps();

  const countryCounts = {};
  let totalVisits = 0;
  const recentVisitors = [];

  for (const ip of ips) {
    const info = logService.getIpSummary(ip);
    if (!info) continue;
    totalVisits += info.visitCount || 0;
    const country = info.lastCountry || 'Unknown';
    countryCounts[country] = (countryCounts[country] || 0) + 1;
    recentVisitors.push({
      ip: info.ip,
      country: info.lastCountry,
      city: info.lastCity,
      lastSeen: info.lastSeen,
      firstSeen: info.firstSeen,
      visitCount: info.visitCount
    });
  }

  recentVisitors.sort((a, b) => new Date(b.lastSeen) - new Date(a.lastSeen));

  const fileNameCounts = {};
  for (const f of files) {
    fileNameCounts[f.name] = (fileNameCounts[f.name] || 0) + 1;
  }
  const topFiles = Object.entries(fileNameCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10)
    .map(([name, count]) => ({ name, count }));

  const topCountries = Object.entries(countryCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10)
    .map(([country, count]) => ({ country, count }));

  const totalDownloads = files.reduce((s, f) => s + (f.downloads || 0), 0);
  const recentUploads = files.slice(0, 20);

  res.json({
    success: true,
    stats: {
      totalVisitors: ips.length,
      totalVisits,
      totalFiles: files.length,
      totalDownloads,
      topCountries,
      topFiles,
      recentVisitors: recentVisitors.slice(0, 20),
      recentUploads
    }
  });
}

function searchByIp(req, res) {
  const ip = req.query.ip;
  if (!isValidIp(ip)) return res.status(400).json({ success: false, error: 'IP غير صالح' });
  const info = logService.getIpSummary(ip);
  const files = metaService.all().filter(f => f.ip === ip);
  res.json({ success: true, info, files, banned: banService.isBanned(ip) });
}

function searchBySession(req, res) {
  const sessionId = req.query.sessionId;
  if (!isValidSessionId(sessionId)) return res.status(400).json({ success: false, error: 'Session غير صالح' });
  const files = metaService.findBySession(sessionId);
  res.json({ success: true, files });
}

function searchByFilename(req, res) {
  const q = String(req.query.name || '').toLowerCase();
  if (!q) return res.status(400).json({ success: false, error: 'اسم الملف مطلوب' });
  const files = metaService.all().filter(f => f.name.toLowerCase().includes(q));
  res.json({ success: true, files });
}

async function deleteFile(req, res) {
  const sid = req.params.sid;
  if (!isValidShortId(sid)) return res.status(400).json({ success: false, error: 'معرف غير صالح' });
  const meta = metaService.findByShortId(sid);
  if (!meta) return res.status(404).json({ success: false, error: 'غير موجود' });

  const fp = safeResolve(config.uploadsDir, meta.filename);
  try { if (fp && fs.existsSync(fp)) fs.unlinkSync(fp); } catch { /* noop */ }
  await metaService.deleteMeta(sid);

  auditService.record('admin_delete_file', { shortId: sid, name: meta.name, admin: req.session.adminUser });
  res.json({ success: true });
}

async function deleteUserFiles(req, res) {
  const { ip, sessionId } = req.body || {};
  if (!ip && !sessionId) return res.status(400).json({ success: false, error: 'ip أو sessionId مطلوب' });

  let removed = [];
  if (sessionId) removed = await metaService.deleteMetaBySession(sessionId);
  else removed = await metaService.deleteMetaByIp(ip);

  for (const meta of removed) {
    const fp = safeResolve(config.uploadsDir, meta.filename);
    try { if (fp && fs.existsSync(fp)) fs.unlinkSync(fp); } catch { /* noop */ }
  }

  auditService.record('admin_delete_user_files', { ip, sessionId, count: removed.length, admin: req.session.adminUser });
  res.json({ success: true, deletedCount: removed.length });
}

function deleteUserLogs(req, res) {
  const { ip } = req.body || {};
  if (!isValidIp(ip)) return res.status(400).json({ success: false, error: 'IP غير صالح' });
  const deleted = logService.deleteIpLogs(ip);
  auditService.record('admin_delete_user_logs', { ip, admin: req.session.adminUser });
  res.json({ success: true, deleted });
}

function banIp(req, res) {
  const { ip } = req.body || {};
  if (!isValidIp(ip)) return res.status(400).json({ success: false, error: 'IP غير صالح' });
  banService.banIp(ip);
  auditService.record('admin_ban_ip', { ip, admin: req.session.adminUser });
  res.json({ success: true });
}

function unbanIp(req, res) {
  const { ip } = req.body || {};
  if (!isValidIp(ip)) return res.status(400).json({ success: false, error: 'IP غير صالح' });
  banService.unbanIp(ip);
  auditService.record('admin_unban_ip', { ip, admin: req.session.adminUser });
  res.json({ success: true });
}

function addBlacklist(req, res) {
  const { ip } = req.body || {};
  if (!isValidIp(ip)) return res.status(400).json({ success: false, error: 'IP غير صالح' });
  banService.addToBlacklist(ip);
  auditService.record('admin_blacklist_add', { ip, admin: req.session.adminUser });
  res.json({ success: true });
}

function removeBlacklist(req, res) {
  const { ip } = req.body || {};
  if (!isValidIp(ip)) return res.status(400).json({ success: false, error: 'IP غير صالح' });
  banService.removeFromBlacklist(ip);
  auditService.record('admin_blacklist_remove', { ip, admin: req.session.adminUser });
  res.json({ success: true });
}

function addWhitelist(req, res) {
  const { ip } = req.body || {};
  if (!isValidIp(ip)) return res.status(400).json({ success: false, error: 'IP غير صالح' });
  banService.addToWhitelist(ip);
  auditService.record('admin_whitelist_add', { ip, admin: req.session.adminUser });
  res.json({ success: true });
}

function removeWhitelist(req, res) {
  const { ip } = req.body || {};
  if (!isValidIp(ip)) return res.status(400).json({ success: false, error: 'IP غير صالح' });
  banService.removeFromWhitelist(ip);
  auditService.record('admin_whitelist_remove', { ip, admin: req.session.adminUser });
  res.json({ success: true });
}

function listBans(req, res) {
  res.json({ success: true, data: banService.load() });
}

function auditLog(req, res) {
  res.json({ success: true, entries: auditService.readAll(500) });
}

module.exports = {
  login, logout, whoami, overview,
  searchByIp, searchBySession, searchByFilename,
  deleteFile, deleteUserFiles, deleteUserLogs,
  banIp, unbanIp, addBlacklist, removeBlacklist, addWhitelist, removeWhitelist,
  listBans, auditLog
};
