'use strict';

const express = require('express');
const path = require('path');
const config = require('../config');
const adminController = require('../controllers/admin.controller');
const { requireAdmin } = require('../middlewares/adminAuth');
const { adminLoginRateLimiter, conditionalCsrf, generateCsrfToken } = require('../middlewares/security');
const asyncHandler = require('../utils/asyncHandler');

const router = express.Router();

// Serve the admin panel HTML shell (protected client-side by requiring login
// via /api/admin/login before any data-bearing API call succeeds).
router.get('/admin', (req, res) => {
  res.sendFile(path.join(config.publicDir, 'admin.html'));
});

// The admin panel fetches a CSRF token here before any mutating request.
router.get('/api/csrf-token', (req, res) => {
  const token = generateCsrfToken(req, res);
  res.json({ success: true, csrfToken: token });
});

router.post('/api/admin/login', adminLoginRateLimiter, adminController.login);
router.post('/api/admin/logout', requireAdmin, conditionalCsrf, adminController.logout);
router.get('/api/admin/whoami', adminController.whoami);

router.get('/api/admin/overview', requireAdmin, adminController.overview);
router.get('/api/admin/search/ip', requireAdmin, adminController.searchByIp);
router.get('/api/admin/search/session', requireAdmin, adminController.searchBySession);
router.get('/api/admin/search/filename', requireAdmin, adminController.searchByFilename);

router.delete('/api/admin/files/:sid', requireAdmin, conditionalCsrf, asyncHandler(adminController.deleteFile));
router.post('/api/admin/delete-user-files', requireAdmin, conditionalCsrf, asyncHandler(adminController.deleteUserFiles));
router.post('/api/admin/delete-user-logs', requireAdmin, conditionalCsrf, adminController.deleteUserLogs);

router.post('/api/admin/ban', requireAdmin, conditionalCsrf, adminController.banIp);
router.post('/api/admin/unban', requireAdmin, conditionalCsrf, adminController.unbanIp);
router.post('/api/admin/blacklist/add', requireAdmin, conditionalCsrf, adminController.addBlacklist);
router.post('/api/admin/blacklist/remove', requireAdmin, conditionalCsrf, adminController.removeBlacklist);
router.post('/api/admin/whitelist/add', requireAdmin, conditionalCsrf, adminController.addWhitelist);
router.post('/api/admin/whitelist/remove', requireAdmin, conditionalCsrf, adminController.removeWhitelist);
router.get('/api/admin/bans', requireAdmin, adminController.listBans);

router.get('/api/admin/audit', requireAdmin, adminController.auditLog);

module.exports = router;
