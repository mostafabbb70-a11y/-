'use strict';

const express = require('express');
const filesController = require('../controllers/files.controller');
const { conditionalCsrf } = require('../middlewares/security');
const asyncHandler = require('../utils/asyncHandler');

const router = express.Router();

router.get('/f/:sid', asyncHandler(filesController.downloadByShortId));
router.get('/api/files', filesController.listFiles);
router.delete('/api/files/:sid', conditionalCsrf, asyncHandler(filesController.deleteFile));
router.get('/api/stats', filesController.stats);

module.exports = router;
