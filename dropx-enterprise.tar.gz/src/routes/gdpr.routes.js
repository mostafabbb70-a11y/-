'use strict';

const express = require('express');
const gdprController = require('../controllers/gdpr.controller');
const { conditionalCsrf } = require('../middlewares/security');
const asyncHandler = require('../utils/asyncHandler');

const router = express.Router();

router.delete('/api/user-data', conditionalCsrf, asyncHandler(gdprController.deleteUserData));

module.exports = router;
