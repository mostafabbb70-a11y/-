'use strict';

const express = require('express');
const { upload } = require('../middlewares/uploadSecurity');
const { uploadRateLimiter } = require('../middlewares/security');
const uploadController = require('../controllers/upload.controller');
const asyncHandler = require('../utils/asyncHandler');

const router = express.Router();

router.post(
  ['/upload', '/api/upload'],
  uploadRateLimiter,
  upload.single('file'),
  asyncHandler(uploadController.handleUpload)
);

module.exports = router;
