'use strict';

const express = require('express');
const path = require('path');
const config = require('../config');
const { pageViewLogger } = require('../middlewares/tracking');

const router = express.Router();

router.get('/', pageViewLogger, (req, res) => {
  const host = req.headers['x-forwarded-host'] || req.headers['x-original-host'] || req.headers.host || '';
  if (host.includes('nexura')) {
    res.sendFile(path.join(config.publicDir, 'nexura.html'));
  } else {
    res.sendFile(path.join(config.publicDir, 'index.html'));
  }
});

router.get('/about', pageViewLogger, (req, res) => res.sendFile(path.join(config.publicDir, 'about.html')));
router.get('/nexura', pageViewLogger, (req, res) => res.sendFile(path.join(config.publicDir, 'nexura.html')));
router.get('/contact', pageViewLogger, (req, res) => res.sendFile(path.join(config.publicDir, 'contact.html')));
router.get('/privacy', pageViewLogger, (req, res) => res.sendFile(path.join(config.publicDir, 'privacy.html')));

module.exports = router;
