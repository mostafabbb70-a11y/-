'use strict';

const xss = require('xss');
const logger = require('../utils/logger');

// Coarse pattern to catch obvious SQL-injection attempts in string inputs.
// This app doesn't use a SQL database, but the check is kept as defense in
// depth for any future integration and to flag/reject clearly malicious input.
const SQLI_PATTERN = /(\b(UNION|SELECT|INSERT|UPDATE|DELETE|DROP|ALTER|EXEC|EXECUTE)\b.{0,20}\b(FROM|INTO|TABLE|WHERE)\b)|(--)|(;\s*--)|(\/\*.*\*\/)/i;

function cleanValue(value) {
  if (typeof value !== 'string') return value;
  return xss(value, { whiteList: {}, stripIgnoreTag: true, stripIgnoreTagBody: ['script', 'style'] });
}

function deepClean(obj) {
  if (Array.isArray(obj)) return obj.map(deepClean);
  if (obj && typeof obj === 'object') {
    const out = {};
    for (const key of Object.keys(obj)) out[key] = deepClean(obj[key]);
    return out;
  }
  return cleanValue(obj);
}

function containsSqliPattern(obj) {
  if (typeof obj === 'string') return SQLI_PATTERN.test(obj);
  if (Array.isArray(obj)) return obj.some(containsSqliPattern);
  if (obj && typeof obj === 'object') return Object.values(obj).some(containsSqliPattern);
  return false;
}

function xssAndInjectionGuard(req, res, next) {
  try {
    if (containsSqliPattern(req.body) || containsSqliPattern(req.query)) {
      logger.warn('Blocked request matching SQL-injection-like pattern', { path: req.path, ip: req.ip });
      return res.status(400).json({ success: false, error: 'طلب غير صالح' });
    }
    req.body = deepClean(req.body);
    req.query = deepClean(req.query);
  } catch (err) {
    logger.error('Sanitization middleware failure', { error: err.message });
  }
  next();
}

module.exports = { xssAndInjectionGuard, cleanValue };
