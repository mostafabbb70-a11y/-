'use strict';

const { normalizeIp } = require('../utils/validators');
const { parseDevice } = require('../utils/deviceParser');
const { lookupGeo } = require('../services/geoService');
const logService = require('../services/logService');
const banService = require('../services/banService');
const logger = require('../utils/logger');

/** Builds a rich visitor-info object from the incoming request. */
function buildVisitorInfo(req) {
  const ip = normalizeIp(req.ip);
  const userAgent = req.headers['user-agent'] || 'Unknown';
  const device = parseDevice(userAgent);
  const geo = lookupGeo(ip, req.headers);
  const sessionId = req.headers['x-session-id'] || (req.session && req.session.id) || ip;

  return {
    ip,
    sessionId,
    userAgent,
    browser: device.browser,
    browserVersion: device.browserVersion,
    os: device.os,
    osVersion: device.osVersion,
    device: device.device,
    language: req.headers['accept-language'] ? req.headers['accept-language'].split(',')[0] : 'Unknown',
    timezone: req.headers['x-timezone'] || 'Unknown',
    country: geo.country,
    city: geo.city,
    referrer: req.headers.referer || req.headers.referrer || 'Direct',
    method: req.method,
    path: req.path,
    headers: {
      accept: req.headers.accept,
      'accept-encoding': req.headers['accept-encoding'],
      'accept-language': req.headers['accept-language']
    }
  };
}

/** Blocks requests from banned/blacklisted IPs. Must run after IP is resolvable. */
function banGuard(req, res, next) {
  const ip = normalizeIp(req.ip);
  if (banService.isBanned(ip)) {
    logger.info('Blocked request from banned IP', { ip, path: req.path });
    return res.status(403).json({ success: false, error: 'تم حظر عنوان IP هذا' });
  }
  next();
}

/** Records a visit (once per request) without blocking the response. */
function visitLogger(req, res, next) {
  const info = buildVisitorInfo(req);
  req.visitor = info;
  // Fire and forget; never block the request on logging.
  logService.recordVisit(info).catch(err => logger.error('recordVisit failed', { error: err.message }));
  next();
}

/** Logs page views for human-facing HTML routes. */
function pageViewLogger(req, res, next) {
  if (req.visitor) {
    logService.recordPageView(req.visitor.ip, {
      path: req.path,
      sessionId: req.visitor.sessionId,
      referrer: req.visitor.referrer
    });
  }
  next();
}

module.exports = { buildVisitorInfo, banGuard, visitLogger, pageViewLogger };
