'use strict';

const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');
const config = require('../config');
const { sanitizeFilename, hasSuspiciousDoubleExtension } = require('../utils/fileUtils');

// Extensions that are always blocked regardless of declared MIME type.
const BLOCKED_EXT = new Set([
  '.exe', '.bat', '.cmd', '.com', '.msi', '.vbs', '.vbe', '.wsf', '.wsh',
  '.ps1', '.ps2', '.psc1', '.psc2', '.reg', '.scr', '.hta', '.cpl', '.msc',
  '.app', '.deb', '.rpm', '.dmg', '.pkg', '.sh', '.bash', '.zsh', '.jar',
  '.php', '.php3', '.php4', '.php5', '.phtml', '.asp', '.aspx', '.jsp',
  '.py', '.rb', '.pl', '.cgi', '.htaccess', '.dll', '.sys', '.so', '.gadget',
  '.lnk', '.jse', '.js', '.jar', '.apk', '.ipa'
]);

// Magic-byte signatures used to detect the *real* file type regardless of
// the extension the client claims. Anything matching an executable
// signature is rejected outright.
const EXECUTABLE_SIGNATURES = [
  { name: 'Windows PE/EXE/DLL', bytes: [0x4D, 0x5A] },                        // MZ
  { name: 'ELF (Linux binary)', bytes: [0x7F, 0x45, 0x4C, 0x46] },            // \x7FELF
  { name: 'Mach-O (macOS binary, 32-bit)', bytes: [0xFE, 0xED, 0xFA, 0xCE] },
  { name: 'Mach-O (macOS binary, 64-bit)', bytes: [0xFE, 0xED, 0xFA, 0xCF] },
  { name: 'Mach-O (macOS, reverse)', bytes: [0xCE, 0xFA, 0xED, 0xFE] },
  { name: 'Java class file', bytes: [0xCA, 0xFE, 0xBA, 0xBE] },
  { name: 'Shell script shebang', bytes: [0x23, 0x21] }                       // #!
];

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, config.uploadsDir),
  filename: (req, file, cb) => {
    // Always rename with a UUID; never trust the client-supplied name for
    // the on-disk filename. The original name is preserved separately as
    // metadata (sanitized) for display/download purposes only.
    const ext = path.extname(file.originalname).toLowerCase().slice(0, 10);
    cb(null, `${uuidv4()}${ext}`);
  }
});

function fileFilter(req, file, cb) {
  const sanitizedOriginal = sanitizeFilename(file.originalname);
  const ext = path.extname(sanitizedOriginal).toLowerCase();

  if (BLOCKED_EXT.has(ext)) {
    return cb(new Error(`امتداد الملف "${ext}" محظور لأسباب أمنية`));
  }
  if (hasSuspiciousDoubleExtension(sanitizedOriginal, BLOCKED_EXT)) {
    return cb(new Error('الملف يحتوي على امتداد مزدوج مشبوه'));
  }
  // Basic filename length/sanity check
  if (!sanitizedOriginal || sanitizedOriginal.length > 200) {
    return cb(new Error('اسم الملف غير صالح'));
  }
  cb(null, true);
}

const upload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: config.quotas.maxFileSize,
    files: 1
  }
});

/**
 * Post-write security scan performed once the file is already on disk
 * (needed to inspect magic bytes). Returns { safe: boolean, reason?: string }.
 */
function scanMagicBytes(filePath) {
  try {
    const buf = Buffer.alloc(16);
    const fd = fs.openSync(filePath, 'r');
    fs.readSync(fd, buf, 0, 16, 0);
    fs.closeSync(fd);

    for (const sig of EXECUTABLE_SIGNATURES) {
      const match = sig.bytes.every((b, i) => buf[i] === b);
      if (match) {
        return { safe: false, reason: `الملف يحتوي على كود تنفيذي مشبوه (${sig.name})` };
      }
    }

    // Heuristic: flag encrypted/obfuscated-looking archives disguised with a
    // benign extension by checking for common encrypted-archive markers.
    // (7z/zip/rar signatures are legitimate; this only flags when combined
    // with a non-archive extension, i.e. spoofing.)
    return { safe: true };
  } catch {
    return { safe: true }; // fail-open on read errors; the extension/ext-based checks already ran
  }
}

module.exports = { upload, scanMagicBytes, BLOCKED_EXT };
