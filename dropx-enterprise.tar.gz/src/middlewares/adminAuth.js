'use strict';

const crypto = require('crypto');
const config = require('../config');

function hashPassword(plain) {
  return crypto.createHash('sha256').update(plain).digest('hex');
}

function verifyPassword(username, password) {
  if (username !== config.admin.username) return false;
  if (config.admin.passwordHash) {
    return hashPassword(password) === config.admin.passwordHash;
  }
  if (config.admin.password) {
    // Constant-time comparison
    const a = Buffer.from(password);
    const b = Buffer.from(config.admin.password);
    if (a.length !== b.length) return false;
    return crypto.timingSafeEqual(a, b);
  }
  return false;
}

function requireAdmin(req, res, next) {
  if (req.session && req.session.isAdmin) return next();
  return res.status(401).json({ success: false, error: 'يجب تسجيل الدخول كأدمن' });
}

module.exports = { verifyPassword, hashPassword, requireAdmin };
