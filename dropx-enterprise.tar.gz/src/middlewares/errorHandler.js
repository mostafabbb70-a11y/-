'use strict';

const multer = require('multer');
const logger = require('../utils/logger');
const logService = require('../services/logService');
const { normalizeIp } = require('../utils/validators');
const { invalidCsrfTokenError } = require('./security');

function notFoundHandler(req, res) {
  res.status(404).json({ success: false, error: 'المسار غير موجود' });
}

// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  const ip = normalizeIp(req.ip);

  if (err === invalidCsrfTokenError || err?.code === 'EBADCSRFTOKEN') {
    logger.warn('CSRF token validation failed', { ip, path: req.path });
    return res.status(403).json({ success: false, error: 'فشل التحقق من CSRF token' });
  }

  if (err instanceof multer.MulterError) {
    let message = 'خطأ أثناء رفع الملف';
    if (err.code === 'LIMIT_FILE_SIZE') message = 'حجم الملف أكبر من الحد المسموح';
    logService.recordFailedUpload(ip, { reason: message, code: err.code });
    return res.status(400).json({ success: false, error: message });
  }

  // Errors thrown from our custom multer fileFilter arrive as plain Error objects.
  if (err && err.message && !err.status) {
    logService.recordFailedUpload(ip, { reason: err.message });
    logService.recordError(ip, { message: err.message, path: req.path });
    return res.status(400).json({ success: false, error: '⚠️ ' + err.message });
  }

  logger.error('Unhandled error', { error: err && err.message, stack: err && err.stack });
  logService.recordError(ip, { message: err && err.message, path: req.path });
  res.status(500).json({ success: false, error: 'حدث خطأ في الخادم' });
}

module.exports = { notFoundHandler, errorHandler };
