'use strict';

const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const session = require('express-session');
const cookieParser = require('cookie-parser');
const hpp = require('hpp');
const { doubleCsrf } = require('csrf-csrf');
const config = require('../config');
const logger = require('../utils/logger');

// ─────────────────────────────────────────
// Helmet: full security header suite
//   - Content-Security-Policy
//   - HSTS
//   - X-Frame-Options (clickjacking)
//   - X-Content-Type-Options (MIME sniffing)
//   - Referrer-Policy
//   - Permissions-Policy (via helmet's permittedCrossDomainPolicies + custom header below)
// ─────────────────────────────────────────
const helmetMiddleware = helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", 'data:', 'blob:'],
      fontSrc: ["'self'", 'data:'],
      connectSrc: ["'self'"],
      objectSrc: ["'none'"],
      frameAncestors: ["'self'"],
      baseUri: ["'self'"],
      formAction: ["'self'"]
    }
  },
  hsts: {
    maxAge: 60 * 60 * 24 * 180, // 180 days
    includeSubDomains: true,
    preload: true
  },
  frameguard: { action: 'sameorigin' },
  noSniff: true,
  referrerPolicy: { policy: 'strict-origin-when-cross-origin' },
  crossOriginResourcePolicy: { policy: 'same-site' }
});

/** Adds Permissions-Policy header (not yet covered by all helmet versions by default). */
function permissionsPolicy(req, res, next) {
  res.setHeader(
    'Permissions-Policy',
    'geolocation=(), microphone=(), camera=(), payment=(), usb=(), interest-cohort=()'
  );
  next();
}

/** Rejects requests whose Host header doesn't match an allow-list (Host header attack defense). */
function hostHeaderProtection(req, res, next) {
  if (config.allowedHosts.length === 0) return next(); // not configured -> skip
  const host = (req.headers.host || '').split(':')[0].toLowerCase();
  const ok = config.allowedHosts.some(allowed => host === allowed.toLowerCase());
  if (!ok) {
    logger.warn('Blocked request with disallowed Host header', { host });
    return res.status(421).json({ success: false, error: 'Misdirected Request' });
  }
  next();
}

/** Blocks directory listing by ensuring static requests target files, not folders, handled at route layer too. */
function noDirectoryListing(staticDir) {
  const path = require('path');
  const fs = require('fs');
  return (req, res, next) => {
    if (req.path === '/' || req.path === '') return next(); // root is handled by the page router, not static listing
    const target = path.join(staticDir, decodeURIComponent(req.path));
    try {
      if (fs.existsSync(target) && fs.statSync(target).isDirectory()) {
        return res.status(403).end();
      }
    } catch {
      // ignore
    }
    next();
  };
}

const generalRateLimiter = rateLimit({
  windowMs: config.rateLimit.windowMs,
  max: config.rateLimit.max,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, error: 'عدد الطلبات كبير جدًا، حاول لاحقًا' }
});

const uploadRateLimiter = rateLimit({
  windowMs: config.rateLimit.uploadWindowMs,
  max: config.rateLimit.uploadMax,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, error: 'تجاوزت الحد المسموح لعدد مرات الرفع، حاول بعد قليل' }
});

const adminLoginRateLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, error: 'محاولات دخول كثيرة جدًا، حاول بعد 15 دقيقة' }
});

const sessionMiddleware = session({
  secret: config.session.secret,
  name: 'ndrop.sid',
  resave: false,
  // Anonymous visitors also need a *stable* session id across requests: it's
  // used both for CSRF token binding (see doubleCsrf below) and as the
  // fallback visitor "Session ID" recorded in logs. With
  // saveUninitialized:false, an unauthenticated session is never persisted,
  // so a fresh id would be minted on every request and CSRF validation
  // would always fail for non-admin flows.
  saveUninitialized: true,
  cookie: {
    httpOnly: true,
    sameSite: 'lax',
    secure: config.session.secureCookie,
    maxAge: config.session.cookieMaxAgeMs
  }
});

const { invalidCsrfTokenError, generateCsrfToken, doubleCsrfProtection } = doubleCsrf({
  getSecret: () => config.session.secret,
  getSessionIdentifier: (req) => (req.session && req.session.id) || req.ip,
  cookieName: config.session.secureCookie ? '__Host-ndrop.csrf' : 'ndrop.csrf',
  cookieOptions: {
    httpOnly: true,
    sameSite: 'lax',
    path: '/',
    secure: config.session.secureCookie
  },
  size: 64,
  ignoredMethods: ['GET', 'HEAD', 'OPTIONS'],
  getCsrfTokenFromRequest: (req) => req.headers['x-csrf-token']
});

/** Recursively strips potentially dangerous keys (prototype pollution / NoSQL injection defense). */
function sanitizeObject(obj) {
  if (!obj || typeof obj !== 'object') return obj;
  for (const key of Object.keys(obj)) {
    if (key.startsWith('$') || key === '__proto__' || key === 'constructor' || key === 'prototype') {
      delete obj[key];
      continue;
    }
    if (obj[key] && typeof obj[key] === 'object') sanitizeObject(obj[key]);
  }
  return obj;
}

function noSqlSanitizer(req, res, next) {
  sanitizeObject(req.body);
  sanitizeObject(req.query);
  sanitizeObject(req.params);
  next();
}

/**
 * Applies CSRF double-submit-cookie protection only to browser/session-based
 * requests. Requests authenticated via API key / Authorization header are
 * treated as programmatic API clients and are exempt (they cannot be forged
 * by a third-party page the way cookie-authenticated browser requests can).
 * This keeps the public upload API backward compatible while still
 * protecting the session-based admin panel and browser-initiated actions.
 */
function conditionalCsrf(req, res, next) {
  const isApiClient = req.headers['x-api-key'] !== undefined || req.headers['authorization'] !== undefined;
  if (isApiClient) return next();
  return doubleCsrfProtection(req, res, next);
}

module.exports = {
  helmetMiddleware,
  permissionsPolicy,
  hostHeaderProtection,
  noDirectoryListing,
  generalRateLimiter,
  uploadRateLimiter,
  adminLoginRateLimiter,
  sessionMiddleware,
  cookieParser: cookieParser(),
  hpp: hpp(),
  csrfProtection: doubleCsrfProtection,
  conditionalCsrf,
  generateCsrfToken,
  invalidCsrfTokenError,
  noSqlSanitizer
};
