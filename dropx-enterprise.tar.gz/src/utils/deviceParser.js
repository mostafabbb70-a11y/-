'use strict';

const uaParserModule = require('ua-parser-js');
const UAParser = uaParserModule.UAParser || uaParserModule;

function parseDevice(userAgent) {
  try {
    const parser = new UAParser(userAgent || '');
    const result = parser.getResult();
    return {
      browser: result.browser.name || 'Unknown',
      browserVersion: result.browser.version || 'Unknown',
      os: result.os.name || 'Unknown',
      osVersion: result.os.version || 'Unknown',
      device: result.device.type || 'desktop',
      deviceVendor: result.device.vendor || 'Unknown',
      deviceModel: result.device.model || 'Unknown'
    };
  } catch {
    return {
      browser: 'Unknown', browserVersion: 'Unknown',
      os: 'Unknown', osVersion: 'Unknown',
      device: 'desktop', deviceVendor: 'Unknown', deviceModel: 'Unknown'
    };
  }
}

module.exports = { parseDevice };
