'use strict';

const crypto = require('crypto');
const path = require('path');
const fs = require('fs');

/**
 * Removes any characters that are not safe for a filename, strips path
 * separators to prevent path traversal, and collapses whitespace.
 */
function sanitizeFilename(name) {
  if (!name || typeof name !== 'string') return 'file';

  // Strip any directory components (path traversal defense)
  let base = path.basename(name);

  // Remove null bytes and control characters
  base = base.replace(/\0/g, '').replace(/[\x00-\x1f\x7f]/g, '');

  // Replace path separators / traversal sequences just in case
  base = base.replace(/\.\./g, '').replace(/[/\\]/g, '_');

  // Keep only a safe character set
  base = base.replace(/[^a-zA-Z0-9._\-\u0600-\u06FF ]/g, '_');

  // Collapse repeated underscores/spaces
  base = base.replace(/\s+/g, ' ').trim();

  if (!base) base = 'file';

  // Limit length
  if (base.length > 180) {
    const ext = path.extname(base);
    base = base.slice(0, 180 - ext.length) + ext;
  }

  return base;
}

/**
 * Detects "double extension" tricks like invoice.pdf.exe by checking every
 * dot-separated segment (not just the immediate inner one) against a
 * blocked-extension set.
 */
function hasSuspiciousDoubleExtension(originalName, blockedExtSet) {
  const parts = originalName.toLowerCase().split('.');
  if (parts.length <= 2) return false; // name.ext -> not double
  // Check every extension-like segment except the final one already checked elsewhere
  for (let i = 1; i < parts.length - 1; i++) {
    if (blockedExtSet.has('.' + parts[i])) return true;
  }
  return false;
}

/**
 * Computes the SHA-256 hash of a file already written to disk.
 */
function sha256File(filePath) {
  return new Promise((resolve, reject) => {
    const hash = crypto.createHash('sha256');
    const stream = fs.createReadStream(filePath);
    stream.on('data', chunk => hash.update(chunk));
    stream.on('end', () => resolve(hash.digest('hex')));
    stream.on('error', reject);
  });
}

/**
 * Ensures a resolved path stays within the expected base directory.
 * Returns the resolved absolute path, or null if traversal is detected.
 */
function safeResolve(baseDir, untrustedRelativePath) {
  const resolvedBase = path.resolve(baseDir);
  const resolvedTarget = path.resolve(baseDir, untrustedRelativePath);
  if (resolvedTarget !== resolvedBase && !resolvedTarget.startsWith(resolvedBase + path.sep)) {
    return null;
  }
  return resolvedTarget;
}

function ensureDir(dir) {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  return dir;
}

module.exports = {
  sanitizeFilename,
  hasSuspiciousDoubleExtension,
  sha256File,
  safeResolve,
  ensureDir
};
