'use strict';

const IP_V4_REGEX = /^(\d{1,3}\.){3}\d{1,3}$/;
const IP_V6_REGEX = /^[0-9a-fA-F:]+$/;
const SESSION_ID_REGEX = /^[a-zA-Z0-9_\-.:]{1,128}$/;
const SHORT_ID_REGEX = /^[a-f0-9]{6,32}$/;

function isValidIp(ip) {
  if (!ip || typeof ip !== 'string') return false;
  return IP_V4_REGEX.test(ip) || (ip.includes(':') && IP_V6_REGEX.test(ip));
}

function isValidSessionId(sid) {
  return typeof sid === 'string' && SESSION_ID_REGEX.test(sid);
}

function isValidShortId(sid) {
  return typeof sid === 'string' && SHORT_ID_REGEX.test(sid);
}

/**
 * Cleans an IP address string already resolved by Express (req.ip), which
 * correctly accounts for the configured number of trusted proxies. This
 * does NOT parse X-Forwarded-For itself - doing so here would let a client
 * simply set that header and spoof any IP, bypassing bans/quotas/logs
 * entirely. Always pass req.ip (never req.headers['x-forwarded-for']).
 */
function normalizeIp(raw) {
  if (!raw) return '0.0.0.0';
  const cleaned = String(raw).replace(/^::ffff:/, '');
  return isValidIp(cleaned) ? cleaned : '0.0.0.0';
}

module.exports = {
  isValidIp,
  isValidSessionId,
  isValidShortId,
  normalizeIp
};
