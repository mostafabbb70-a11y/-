'use strict';

/**
 * Express 4 does not automatically forward rejected promises from async
 * route handlers to the error-handling middleware. This wrapper ensures any
 * thrown/rejected error is passed to next(err) instead of crashing the
 * process or leaving the request hanging.
 */
function asyncHandler(fn) {
  return function (req, res, next) {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
}

module.exports = asyncHandler;
