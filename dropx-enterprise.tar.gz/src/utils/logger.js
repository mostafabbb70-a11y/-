'use strict';

const winston = require('winston');
const path = require('path');
const fs = require('fs');
const config = require('../config');

const appLogDir = path.join(config.logsDir, '_app');
if (!fs.existsSync(appLogDir)) fs.mkdirSync(appLogDir, { recursive: true });

const logger = winston.createLogger({
  level: config.env === 'development' ? 'debug' : 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.errors({ stack: true }),
    winston.format.json()
  ),
  transports: [
    new winston.transports.File({ filename: path.join(appLogDir, 'error.log'), level: 'error' }),
    new winston.transports.File({ filename: path.join(appLogDir, 'combined.log') })
  ]
});

if (config.env !== 'production') {
  logger.add(new winston.transports.Console({
    format: winston.format.combine(
      winston.format.colorize(),
      winston.format.simple()
    )
  }));
} else {
  // Keep minimal console output in production for platform health checks.
  logger.add(new winston.transports.Console({
    format: winston.format.simple(),
    level: 'info'
  }));
}

module.exports = logger;
