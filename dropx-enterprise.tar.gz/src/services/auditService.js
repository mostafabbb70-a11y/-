'use strict';

const fs = require('fs');
const path = require('path');
const config = require('../config');
const { ensureDir } = require('../utils/fileUtils');

ensureDir(path.dirname(config.auditFile));

function record(action, details = {}) {
  const entry = {
    ts: new Date().toISOString(),
    action,
    ...details
  };
  fs.appendFile(config.auditFile, JSON.stringify(entry) + '\n', () => {});
  return entry;
}

function readAll(limit = 500) {
  try {
    const content = fs.readFileSync(config.auditFile, 'utf8');
    const lines = content.trim().split('\n').filter(Boolean);
    return lines.slice(-limit).map(l => {
      try { return JSON.parse(l); } catch { return null; }
    }).filter(Boolean).reverse();
  } catch {
    return [];
  }
}

module.exports = { record, readAll };
