'use strict';

const fs = require('fs');
const path = require('path');
const config = require('../config');
const { ensureDir } = require('../utils/fileUtils');
const logger = require('../utils/logger');

ensureDir(path.dirname(config.metaFile));

// One-time migration: if a legacy meta.json exists at the project root, move it in.
const legacyMetaFile = path.join(config.rootDir, 'meta.json');
if (!fs.existsSync(config.metaFile) && fs.existsSync(legacyMetaFile)) {
  try {
    fs.copyFileSync(legacyMetaFile, config.metaFile);
    logger.info('Migrated legacy meta.json into data/meta.json');
  } catch (err) {
    logger.error('Failed to migrate legacy meta.json', { error: err.message });
  }
}

let writeQueue = Promise.resolve();

function loadMeta() {
  try {
    return JSON.parse(fs.readFileSync(config.metaFile, 'utf8'));
  } catch {
    return [];
  }
}

function persist(all) {
  // Serialize writes to avoid interleaved/corrupted JSON under concurrency.
  writeQueue = writeQueue.then(() => {
    const tmp = config.metaFile + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(all, null, 2));
    fs.renameSync(tmp, config.metaFile);
  }).catch(err => logger.error('Failed to persist meta.json', { error: err.message }));
  return writeQueue;
}

async function saveMeta(info) {
  const all = loadMeta();
  all.unshift(info);
  await persist(all);
  return info;
}

async function deleteMeta(shortId) {
  const all = loadMeta();
  const filtered = all.filter(f => f.shortId !== shortId);
  await persist(filtered);
  return all.length !== filtered.length;
}

async function deleteMetaBySession(sessionId) {
  const all = loadMeta();
  const removed = all.filter(f => f.sessionId === sessionId);
  const filtered = all.filter(f => f.sessionId !== sessionId);
  await persist(filtered);
  return removed;
}

async function deleteMetaByIp(ip) {
  const all = loadMeta();
  const removed = all.filter(f => f.ip === ip);
  const filtered = all.filter(f => f.ip !== ip);
  await persist(filtered);
  return removed;
}

async function incrementDownload(shortId) {
  const all = loadMeta();
  const idx = all.findIndex(f => f.shortId === shortId);
  if (idx === -1) return null;
  all[idx].downloads = (all[idx].downloads || 0) + 1;
  await persist(all);
  return all[idx];
}

function findByShortId(shortId) {
  return loadMeta().find(f => f.shortId === shortId) || null;
}

function findBySession(sessionId) {
  return loadMeta().filter(f => f.sessionId === sessionId);
}

function findByHash(hash) {
  return loadMeta().find(f => f.sha256 === hash) || null;
}

function getSessionUsage(sessionId) {
  return findBySession(sessionId).reduce((s, f) => s + (f.size || 0), 0);
}

function all() {
  return loadMeta();
}

module.exports = {
  loadMeta,
  saveMeta,
  deleteMeta,
  deleteMetaBySession,
  deleteMetaByIp,
  incrementDownload,
  findByShortId,
  findBySession,
  findByHash,
  getSessionUsage,
  all
};
