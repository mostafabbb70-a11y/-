'use strict';

let geoip = null;
try {
  // Optional dependency: offline IP -> location database. If not installed,
  // we gracefully fall back to CDN-provided headers only.
  geoip = require('geoip-lite');
} catch {
  geoip = null;
}

/**
 * Resolves country/city for a request. Prefers headers set by trusted
 * reverse proxies / CDNs (Cloudflare, Vercel, etc.) since they're generally
 * more accurate and require no local database, then falls back to a local
 * offline geoip database, and finally to 'Unknown'.
 */
function lookupGeo(ip, headers = {}) {
  const cfCountry = headers['cf-ipcountry'];
  const vercelCountry = headers['x-vercel-ip-country'];
  const vercelCity = headers['x-vercel-ip-city'];

  if (cfCountry && cfCountry !== 'XX') {
    return { country: cfCountry, city: headers['cf-ipcity'] || 'Unknown' };
  }
  if (vercelCountry) {
    return { country: vercelCountry, city: vercelCity ? decodeURIComponent(vercelCity) : 'Unknown' };
  }

  if (geoip && ip && ip !== '0.0.0.0' && ip !== '127.0.0.1') {
    try {
      const result = geoip.lookup(ip);
      if (result) {
        return { country: result.country || 'Unknown', city: (result.city || 'Unknown') };
      }
    } catch {
      // ignore lookup errors
    }
  }

  return { country: 'Unknown', city: 'Unknown' };
}

module.exports = { lookupGeo };
