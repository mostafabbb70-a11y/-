'use strict';

const fs = require('fs');
const path = require('path');
const config = require('../config');
const { ensureDir } = require('../utils/fileUtils');

ensureDir(path.dirname(config.banFile));

function load() {
  try {
    return JSON.parse(fs.readFileSync(config.banFile, 'utf8'));
  } catch {
    return { banned: [], blacklist: [], whitelist: [] };
  }
}

function save(data) {
  const tmp = config.banFile + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2));
  fs.renameSync(tmp, config.banFile);
}

function isWhitelisted(ip) {
  const data = load();
  return data.whitelist.includes(ip);
}

function isBanned(ip) {
  const data = load();
  if (data.whitelist.includes(ip)) return false;
  return data.banned.includes(ip) || data.blacklist.includes(ip);
}

function banIp(ip) {
  const data = load();
  if (!data.banned.includes(ip)) data.banned.push(ip);
  save(data);
  return data;
}

function unbanIp(ip) {
  const data = load();
  data.banned = data.banned.filter(i => i !== ip);
  save(data);
  return data;
}

function addToBlacklist(ip) {
  const data = load();
  if (!data.blacklist.includes(ip)) data.blacklist.push(ip);
  save(data);
  return data;
}

function removeFromBlacklist(ip) {
  const data = load();
  data.blacklist = data.blacklist.filter(i => i !== ip);
  save(data);
  return data;
}

function addToWhitelist(ip) {
  const data = load();
  if (!data.whitelist.includes(ip)) data.whitelist.push(ip);
  save(data);
  return data;
}

function removeFromWhitelist(ip) {
  const data = load();
  data.whitelist = data.whitelist.filter(i => i !== ip);
  save(data);
  return data;
}

module.exports = {
  load,
  isWhitelisted,
  isBanned,
  banIp,
  unbanIp,
  addToBlacklist,
  removeFromBlacklist,
  addToWhitelist,
  removeFromWhitelist
};
