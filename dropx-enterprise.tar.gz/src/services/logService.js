'use strict';

const fs = require('fs');
const path = require('path');
const config = require('../config');
const { ensureDir } = require('../utils/fileUtils');
const logger = require('../utils/logger');

// Simple in-process mutex per IP folder to avoid concurrent read-modify-write
// corruption on info.json when multiple requests from the same IP race.
const locks = new Map();
async function withLock(key, fn) {
  const prev = locks.get(key) || Promise.resolve();
  let release;
  const p = new Promise(res => { release = res; });
  locks.set(key, prev.then(() => p));
  await prev;
  try {
    return await fn();
  } finally {
    release();
    if (locks.get(key) === p) locks.delete(key);
  }
}

/** Turns a raw IP into a filesystem-safe directory name. */
function ipToDirName(ip) {
  return String(ip).replace(/[^a-zA-Z0-9.:_-]/g, '_');
}

function ipDir(ip) {
  return ensureDir(path.join(config.logsDir, ipToDirName(ip)));
}

function appendLine(filePath, obj) {
  const line = JSON.stringify({ ...obj, ts: new Date().toISOString() }) + '\n';
  fs.appendFile(filePath, line, err => {
    if (err) logger.error('Failed to append log line', { file: filePath, error: err.message });
  });
}

function readInfo(dir) {
  const infoPath = path.join(dir, 'info.json');
  try {
    return JSON.parse(fs.readFileSync(infoPath, 'utf8'));
  } catch {
    return null;
  }
}

function writeInfo(dir, info) {
  const infoPath = path.join(dir, 'info.json');
  fs.writeFileSync(infoPath, JSON.stringify(info, null, 2));
}

/**
 * Records a visit for a given IP, updating info.json (first/last seen, visit
 * count, device/geo info) and appending a line to visits.log.
 */
async function recordVisit(visitorInfo) {
  const { ip } = visitorInfo;
  return withLock(ip, () => {
    const dir = ipDir(ip);
    let info = readInfo(dir);
    const now = new Date().toISOString();

    if (!info) {
      info = {
        ip,
        firstSeen: now,
        lastSeen: now,
        visitCount: 0,
        sessions: [],
        lastUserAgent: null,
        lastCountry: null,
        lastCity: null
      };
    }

    info.lastSeen = now;
    info.visitCount = (info.visitCount || 0) + 1;
    info.lastUserAgent = visitorInfo.userAgent;
    info.lastCountry = visitorInfo.country;
    info.lastCity = visitorInfo.city;
    if (visitorInfo.sessionId && !info.sessions.includes(visitorInfo.sessionId)) {
      info.sessions.push(visitorInfo.sessionId);
    }

    writeInfo(dir, info);
    appendLine(path.join(dir, 'visits.log'), visitorInfo);
    return info;
  });
}

function recordPageView(ip, data) {
  const dir = ipDir(ip);
  appendLine(path.join(dir, 'pages.log'), data);
}

function recordUpload(ip, data) {
  const dir = ipDir(ip);
  appendLine(path.join(dir, 'uploads.log'), data);
}

function recordFailedUpload(ip, data) {
  const dir = ipDir(ip);
  appendLine(path.join(dir, 'uploads.log'), { ...data, failed: true });
}

function recordDownload(ip, data) {
  const dir = ipDir(ip);
  appendLine(path.join(dir, 'downloads.log'), data);
}

function recordError(ip, data) {
  const dir = ipDir(ip || 'unknown');
  appendLine(path.join(dir, 'errors.log'), data);
}

/** Returns a list of all IP directories currently tracked. */
function listAllIps() {
  ensureDir(config.logsDir);
  return fs.readdirSync(config.logsDir).filter(name => {
    const full = path.join(config.logsDir, name);
    return fs.statSync(full).isDirectory() && name !== '_app';
  });
}

function getIpSummary(ip) {
  const dir = ipDir(ip);
  return readInfo(dir);
}

/** Deletes all logs for a given IP (used by GDPR deletion + admin panel). */
function deleteIpLogs(ip) {
  const dir = path.join(config.logsDir, ipToDirName(ip));
  if (fs.existsSync(dir)) {
    fs.rmSync(dir, { recursive: true, force: true });
    return true;
  }
  return false;
}

module.exports = {
  recordVisit,
  recordPageView,
  recordUpload,
  recordFailedUpload,
  recordDownload,
  recordError,
  listAllIps,
  getIpSummary,
  deleteIpLogs,
  ipDir,
  ipToDirName
};
