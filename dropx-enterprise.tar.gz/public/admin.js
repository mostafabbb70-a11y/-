(function () {
  'use strict';

  let csrfToken = null;

  function el(id) { return document.getElementById(id); }

  async function getCsrfToken() {
    const res = await fetch('/api/csrf-token', { credentials: 'include' });
    const data = await res.json();
    csrfToken = data.csrfToken;
    return csrfToken;
  }

  async function api(path, options = {}) {
    const opts = {
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      ...options
    };
    if (options.method && options.method !== 'GET') {
      // Always fetch a fresh token: the session identifier a CSRF token is
      // bound to changes the moment login succeeds (a new session cookie is
      // issued), so a token cached from before login would no longer
      // validate against the now-authenticated session.
      await getCsrfToken();
      opts.headers['X-CSRF-Token'] = csrfToken;
    }
    const res = await fetch(path, opts);
    return res.json();
  }

  function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = String(str == null ? '' : str);
    return div.innerHTML;
  }

  function showDashboard() {
    el('login-view').classList.add('hidden');
    el('dashboard-view').classList.remove('hidden');
    loadOverview();
    loadBans();
  }

  function showLogin() {
    el('dashboard-view').classList.add('hidden');
    el('login-view').classList.remove('hidden');
  }

  async function checkSession() {
    const data = await api('/api/admin/whoami');
    if (data.isAdmin) showDashboard(); else showLogin();
  }

  el('login-btn').addEventListener('click', async () => {
    const username = el('login-username').value.trim();
    const password = el('login-password').value;
    el('login-msg').textContent = '';
    const data = await api('/api/admin/login', {
      method: 'POST',
      body: JSON.stringify({ username, password })
    });
    if (data.success) {
      showDashboard();
    } else {
      el('login-msg').textContent = data.error || 'فشل تسجيل الدخول';
    }
  });

  el('logout-btn').addEventListener('click', async () => {
    await api('/api/admin/logout', { method: 'POST' });
    showLogin();
  });

  async function loadOverview() {
    const data = await api('/api/admin/overview');
    if (!data.success) return;
    const s = data.stats;

    el('stats-grid').innerHTML = `
      <div class="stat-card"><div class="num">${s.totalVisitors}</div><div class="label">عدد الزوار</div></div>
      <div class="stat-card"><div class="num">${s.totalVisits}</div><div class="label">إجمالي الزيارات</div></div>
      <div class="stat-card"><div class="num">${s.totalFiles}</div><div class="label">عدد الملفات</div></div>
      <div class="stat-card"><div class="num">${s.totalDownloads}</div><div class="label">عدد التحميلات</div></div>
    `;

    el('recent-visitors').innerHTML = renderTable(
      ['IP', 'الدولة', 'المدينة', 'آخر ظهور', 'عدد الزيارات', ''],
      s.recentVisitors.map(v => [
        escapeHtml(v.ip), escapeHtml(v.country), escapeHtml(v.city),
        new Date(v.lastSeen).toLocaleString('ar'), v.visitCount,
        rowActionsForIp(v.ip)
      ])
    );

    el('recent-uploads').innerHTML = renderTable(
      ['الاسم', 'الحجم', 'IP', 'التاريخ', 'تحميلات', ''],
      s.recentUploads.map(f => [
        escapeHtml(f.name), fmtSize(f.size), escapeHtml(f.ip),
        new Date(f.date).toLocaleString('ar'), f.downloads,
        `<div class="row-actions"><button data-del-file="${escapeHtml(f.shortId)}">حذف</button></div>`
      ])
    );

    document.querySelectorAll('[data-del-file]').forEach(btn => {
      btn.addEventListener('click', async () => {
        if (!confirm('حذف هذا الملف؟')) return;
        await api(`/api/admin/files/${btn.dataset.delFile}`, { method: 'DELETE' });
        loadOverview();
      });
    });
    document.querySelectorAll('[data-ban-ip]').forEach(bindIpActionButtons);
  }

  function rowActionsForIp(ip) {
    return `<div class="row-actions">
      <button data-ban-ip="${escapeHtml(ip)}" data-action="ban">Ban</button>
      <button data-ban-ip="${escapeHtml(ip)}" data-action="delete-files">حذف ملفاته</button>
      <button data-ban-ip="${escapeHtml(ip)}" data-action="delete-logs">حذف Logs</button>
    </div>`;
  }

  function bindIpActionButtons(btn) {
    btn.addEventListener('click', async () => {
      const ip = btn.dataset.banIp;
      const action = btn.dataset.action;
      if (action === 'ban') {
        await api('/api/admin/ban', { method: 'POST', body: JSON.stringify({ ip }) });
      } else if (action === 'delete-files') {
        if (!confirm(`حذف كل ملفات ${ip}؟`)) return;
        await api('/api/admin/delete-user-files', { method: 'POST', body: JSON.stringify({ ip }) });
      } else if (action === 'delete-logs') {
        if (!confirm(`حذف كل logs الخاصة بـ ${ip}؟`)) return;
        await api('/api/admin/delete-user-logs', { method: 'POST', body: JSON.stringify({ ip }) });
      }
      loadOverview();
      loadBans();
    });
  }

  function renderTable(headers, rows) {
    if (!rows.length) return '<p style="color:var(--muted);font-size:13px;">لا توجد بيانات</p>';
    const thead = `<tr>${headers.map(h => `<th>${h}</th>`).join('')}</tr>`;
    const tbody = rows.map(r => `<tr>${r.map(c => `<td>${c}</td>`).join('')}</tr>`).join('');
    return `<table>${thead}${tbody}</table>`;
  }

  function fmtSize(b) {
    b = Number(b) || 0;
    if (b < 1024) return b + ' B';
    if (b < 1048576) return (b / 1024).toFixed(1) + ' KB';
    return (b / 1048576).toFixed(2) + ' MB';
  }

  el('search-ip-btn').addEventListener('click', async () => {
    const ip = el('search-ip').value.trim();
    if (!ip) return;
    const data = await api(`/api/admin/search/ip?ip=${encodeURIComponent(ip)}`);
    if (!data.success) { el('search-results').textContent = data.error; return; }
    el('search-results').innerHTML = `
      <p style="margin-bottom:8px;">حالة الحظر: <span class="tag">${data.banned ? 'محظور' : 'غير محظور'}</span></p>
      ${renderTable(['الاسم', 'الحجم', 'التاريخ', 'تحميلات'], (data.files || []).map(f => [
        escapeHtml(f.name), fmtSize(f.size), new Date(f.date).toLocaleString('ar'), f.downloads
      ]))}
    `;
  });

  el('search-session-btn').addEventListener('click', async () => {
    const sessionId = el('search-session').value.trim();
    if (!sessionId) return;
    const data = await api(`/api/admin/search/session?sessionId=${encodeURIComponent(sessionId)}`);
    el('search-results').innerHTML = renderTable(['الاسم', 'الحجم', 'التاريخ'], (data.files || []).map(f => [
      escapeHtml(f.name), fmtSize(f.size), new Date(f.date).toLocaleString('ar')
    ]));
  });

  el('search-filename-btn').addEventListener('click', async () => {
    const name = el('search-filename').value.trim();
    if (!name) return;
    const data = await api(`/api/admin/search/filename?name=${encodeURIComponent(name)}`);
    el('search-results').innerHTML = renderTable(['الاسم', 'الحجم', 'IP', 'التاريخ'], (data.files || []).map(f => [
      escapeHtml(f.name), fmtSize(f.size), escapeHtml(f.ip), new Date(f.date).toLocaleString('ar')
    ]));
  });

  el('ban-btn').addEventListener('click', async () => {
    const ip = el('ban-ip').value.trim();
    if (!ip) return;
    await api('/api/admin/ban', { method: 'POST', body: JSON.stringify({ ip }) });
    loadBans();
  });
  el('unban-btn').addEventListener('click', async () => {
    const ip = el('ban-ip').value.trim();
    if (!ip) return;
    await api('/api/admin/unban', { method: 'POST', body: JSON.stringify({ ip }) });
    loadBans();
  });
  el('blacklist-btn').addEventListener('click', async () => {
    const ip = el('ban-ip').value.trim();
    if (!ip) return;
    await api('/api/admin/blacklist/add', { method: 'POST', body: JSON.stringify({ ip }) });
    loadBans();
  });
  el('whitelist-btn').addEventListener('click', async () => {
    const ip = el('ban-ip').value.trim();
    if (!ip) return;
    await api('/api/admin/whitelist/add', { method: 'POST', body: JSON.stringify({ ip }) });
    loadBans();
  });

  async function loadBans() {
    const data = await api('/api/admin/bans');
    if (!data.success) return;
    const d = data.data;
    el('bans-list').innerHTML = `
      <p><strong>Banned:</strong> ${d.banned.map(escapeHtml).join(', ') || '—'}</p>
      <p><strong>Blacklist:</strong> ${d.blacklist.map(escapeHtml).join(', ') || '—'}</p>
      <p><strong>Whitelist:</strong> ${d.whitelist.map(escapeHtml).join(', ') || '—'}</p>
    `;
  }

  checkSession();
})();
